# aiLayer/decision_engine.py

import os
from mcpClient import call_mcp_tool


def decide_and_execute(context: dict):
    """
    Routes execution based on file type or code review analysis.
    Standardises output so Frontend always receives 'endpoint'.

    Deployment paths:
      A. JAR artifact         → EC2 Java
      B. algorand_dapp        → Algorand testnet + Amplify frontend (if exists)
      C. frontend             → Amplify (snapshot or CI/CD)
      D. backend / fullstack  → EC2 source deploy
    """
    print("\n🤔 [DECISION ENGINE] Analysing context...")

    # ═══════════════════════════════════════════════════
    # PATH A: JAR ARTIFACT → EC2 Java
    # ═══════════════════════════════════════════════════
    if context.get("artifact_type") == "jar":
        jar_path = context.get("artifact_path")
        print("🤖 [AI] Artifact detected. Route: Java EC2 Deploy")

        call_mcp_tool("provision_ec2_instance", {})
        deploy_res = call_mcp_tool("deploy_java_app_ec2", {"artifact_path": jar_path})

        public_ip = deploy_res.get("public_ip")
        endpoint  = f"http://{public_ip}:8080" if public_ip else None

        return {
            "status":     "success",
            "deployment": "ec2_java_artifact",
            "public_ip":  public_ip,
            "endpoint":   endpoint,
            "message":    "Java Application Deployed Successfully via EC2."
        }

    # ── Parse AI review output ────────────────────────
    review       = context.get("ai_understanding", {})
    project_type = review.get("project_type", "unknown").lower()
    language     = review.get("language", "unknown").lower()
    entry_point  = review.get("entry_point", "")

    print(f"📊 [DEBUG] Type: {project_type} | Lang: {language} | Entry: {entry_point}")
    print(f"📊 [DEBUG] Is Algorand dApp: {review.get('is_algorand_dapp', False)}")

    # ═══════════════════════════════════════════════════
    # PATH B: ALGORAND DAPP → Contract + Amplify
    # ═══════════════════════════════════════════════════
    if project_type == "algorand_dapp" or review.get("is_algorand_dapp"):
        print("🤖 [AI] Decision: Algorand dApp detected.")

        project_path  = context.get("project_path")
        contract_file = review.get("contract_file")
        frontend_dir  = review.get("frontend_dir")
        base_name     = (
            context.get("filename", "app")
            .replace(".zip", "")
            .replace(".", "-")
            .split("/")[-1]
        )

        # ── Step 1: Deploy smart contract to Algorand ──
        print("    [1/3] Deploying Algorand smart contract...")
        contract_result = call_mcp_tool("deploy_algorand_contract", {
            "project_path":  project_path,
            "contract_file": contract_file
        })

        if contract_result.get("status") == "error":
            return {
                "status":     "error",
                "deployment": "algorand_dapp",
                "message":    f"Contract deployment failed: {contract_result.get('message')}",
                "endpoint":   None
            }

        app_id       = contract_result.get("app_id")
        app_address  = contract_result.get("app_address")
        explorer_url = contract_result.get("explorer_url")

        print(f"    ✅ Contract live. App ID: {app_id}")

        # ── Step 2: Deploy frontend to Amplify if exists ──
        frontend_url = None
        if frontend_dir:
            print(f"    [2/3] Deploying frontend from: {frontend_dir}")
            frontend_path = os.path.join(project_path, frontend_dir)
            app_name      = f"opsonic-{base_name}"

            repo_url     = context.get("repo_url")
            github_token = context.get("github_token")

            if repo_url and github_token and "github.com" in repo_url:
                deploy_res = call_mcp_tool("connect_amplify_cicd", {
                    "repo_url":     repo_url,
                    "github_token": github_token,
                    "app_name":     app_name
                })
            else:
                deploy_res = call_mcp_tool("deploy_to_amplify", {
                    "source_path": frontend_path,
                    "app_name":    app_name
                })

            frontend_url = deploy_res.get("url") or deploy_res.get("endpoint")
            print(f"    ✅ Frontend live: {frontend_url}")
        else:
            print("    [2/3] No frontend directory — skipping Amplify deploy.")

        print("    [3/3] Done.")

        return {
            "status":       "success",
            "deployment":   "algorand_dapp",
            "app_id":       app_id,
            "app_address":  app_address,
            "explorer_url": explorer_url,
            "network":      "algorand-testnet",
            "endpoint":     frontend_url,
            "message": (
                f"Algorand dApp deployed. Contract App ID: {app_id}. "
                + (f"Frontend: {frontend_url}" if frontend_url else "No frontend detected.")
            )
        }

    # ═══════════════════════════════════════════════════
    # PATH C: FRONTEND → Amplify
    # ═══════════════════════════════════════════════════
    if project_type == "frontend" or language == "static":
        print("🤖 [AI] Decision: Frontend detected.")

        repo_url     = context.get("repo_url")
        github_token = context.get("github_token")
        base_name    = (
            context.get("filename", "app")
            .replace(".zip", "")
            .replace(".", "-")
            .split("/")[-1]
        )
        app_name = f"opsonic-{base_name}"

        if repo_url and github_token and "github.com" in repo_url:
            print("✨ [PLAN] GitHub credentials found. Setting up Continuous Deployment.")
            res = call_mcp_tool("connect_amplify_cicd", {
                "repo_url":     repo_url,
                "github_token": github_token,
                "app_name":     app_name
            })
            res["endpoint"] = res.get("url") or res.get("endpoint")
            return res
        else:
            print("📸 [PLAN] Zip/No-Token. Performing Snapshot Deployment.")
            project_path = context.get("project_path")
            deploy_res   = call_mcp_tool("deploy_to_amplify", {
                "source_path": project_path,
                "app_name":    app_name
            })
            deploy_res["warning"]  = (
                "⚠️ SNAPSHOT DEPLOYMENT: Future changes will NOT auto-update."
            )
            deploy_res["endpoint"] = deploy_res.get("url")
            return deploy_res

    # ═══════════════════════════════════════════════════
    # PATH D: BACKEND / FULLSTACK → EC2 Source
    # ═══════════════════════════════════════════════════
    if project_type in ["backend", "fullstack"]:
        print(f"🤖 [AI] Decision: {language.title()} Backend → EC2 Source Deploy")

        print("    1. Provisioning Server...")
        call_mcp_tool("provision_ec2_instance", {})

        print(f"    2. Deploying {language} app (Entry: {entry_point})...")
        deploy_res = call_mcp_tool("deploy_source_ec2", {
            "source_path": context.get("project_path"),
            "language":    language,
            "entry_point": entry_point
        })

        public_ip = deploy_res.get("public_ip")
        endpoint  = f"http://{public_ip}:8080" if public_ip else None

        return {
            "status":     "success",
            "deployment": "ec2_source_code",
            "public_ip":  public_ip,
            "endpoint":   endpoint,
            "message":    f"Deployed {language} backend successfully."
        }

    return {
        "status":  "manual",
        "message": "Unknown project type. Please deploy manually."
    }
