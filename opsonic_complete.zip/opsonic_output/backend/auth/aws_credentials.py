# auth/aws_credentials.py

import os
import getpass


def ask_aws_credentials() -> dict:
    """Terminal fallback. Called only when vault and env both fail."""
    print("\n🔐 ENTER AWS IAM CREDENTIALS\n")
    access_key = input("AWS_ACCESS_KEY_ID: ").strip()
    secret_key = getpass.getpass("AWS_SECRET_ACCESS_KEY (hidden): ").strip()
    region     = input("AWS_DEFAULT_REGION (e.g. ap-south-1): ").strip() or "ap-south-1"
    if not access_key or not secret_key:
        raise ValueError("AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY are required")
    return {
        "AWS_ACCESS_KEY_ID":     access_key,
        "AWS_SECRET_ACCESS_KEY": secret_key,
        "AWS_DEFAULT_REGION":    region
    }


def inject_aws_creds(creds: dict) -> None:
    """Inject credentials into runtime environment only. Never written to disk."""
    os.environ["AWS_ACCESS_KEY_ID"]     = creds["AWS_ACCESS_KEY_ID"]
    os.environ["AWS_SECRET_ACCESS_KEY"] = creds["AWS_SECRET_ACCESS_KEY"]
    os.environ["AWS_DEFAULT_REGION"]    = creds.get("AWS_DEFAULT_REGION", "ap-south-1")
    print("🔑 [AUTH] AWS credentials injected into runtime environment.")


def resolve_aws_credentials(
    access_key_id:     str | None = None,
    secret_access_key: str | None = None,
    region:            str        = "ap-south-1"
) -> dict:
    """
    Credential resolution pipeline — priority order:
    1. Full credentials from frontend (both key + secret provided)
    2. Algorand vault lookup (access_key_id provided, secret missing)
    3. Environment variables (.env / OS env)
    4. Terminal prompt (last resort)
    """

    # ── Priority 1: Full creds from frontend ───────────────────────────────
    if access_key_id and secret_access_key:
        print("🔑 [AUTH] Using credentials from frontend.")
        creds = {
            "AWS_ACCESS_KEY_ID":     access_key_id,
            "AWS_SECRET_ACCESS_KEY": secret_access_key,
            "AWS_DEFAULT_REGION":    region
        }
        inject_aws_creds(creds)
        return creds

    # ── Priority 2: Algorand vault lookup ──────────────────────────────────
    if access_key_id:
        print(f"🔍 [AUTH] Checking Algorand vault for: {access_key_id[:8]}****")
        try:
            from mcpServer.infraScripts.algorand_credential_store import (
                retrieve_aws_credentials,
                has_credentials
            )
            if has_credentials(access_key_id):
                print("✅ [AUTH] Found in Algorand vault. Retrieving...")
                creds = retrieve_aws_credentials(access_key_id)
                inject_aws_creds(creds)
                return creds
            else:
                print("⚠️  [AUTH] No vault entry found for this access key ID.")
        except EnvironmentError:
            # Vault not configured — CREDENTIAL_VAULT_APP_ID missing
            print("⚠️  [AUTH] Vault not configured. Skipping vault lookup.")
        except Exception as e:
            print(f"⚠️  [AUTH] Vault lookup failed: {e}")

    # ── Priority 3: Environment variables ──────────────────────────────────
    env_key    = os.environ.get("AWS_ACCESS_KEY_ID", "")
    env_secret = os.environ.get("AWS_SECRET_ACCESS_KEY", "")
    if env_key and env_secret:
        print("🔑 [AUTH] Using credentials from environment variables.")
        creds = {
            "AWS_ACCESS_KEY_ID":     env_key,
            "AWS_SECRET_ACCESS_KEY": env_secret,
            "AWS_DEFAULT_REGION":    os.environ.get("AWS_DEFAULT_REGION", region)
        }
        inject_aws_creds(creds)
        return creds

    # ── Priority 4: Terminal prompt ────────────────────────────────────────
    print("⚠️  [AUTH] No credentials found anywhere. Falling back to terminal.")
    creds = ask_aws_credentials()
    inject_aws_creds(creds)
    return creds
