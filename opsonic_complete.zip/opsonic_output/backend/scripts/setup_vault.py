# scripts/setup_vault.py
# Run ONCE before the hackathon demo to deploy the CredentialVault contract.
# Automatically writes CREDENTIAL_VAULT_APP_ID to your .env file.
#
# Usage:
#   cd backend
#   python scripts/setup_vault.py

import os
import sys
import base64
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

# ─────────────────────────────────────────────────────────────────────────────
# INLINE TEAL
# Using hand-written TEAL so you don't need algokit installed to run setup.
# Logic: only creator can call store/delete, anyone can read via algod API.
# ─────────────────────────────────────────────────────────────────────────────

APPROVAL_TEAL = """#pragma version 9
// ── Allow on creation ────────────────────────────────
txn ApplicationID
int 0
==
bz check_sender

b allow

// ── All other calls: only creator ────────────────────
check_sender:
txn Sender
global CreatorAddress
==
assert

// ── Route by first argument ───────────────────────────
txn NumAppArgs
int 1
>=
bz allow

txn ApplicationArgs 0
byte "store"
==
bz check_delete

// STORE: app_args[1]=box_key(32 bytes), app_args[2]=encrypted_blob
txn ApplicationArgs 1
txn ApplicationArgs 2
box_put
b allow

check_delete:
txn ApplicationArgs 0
byte "delete"
==
bz allow

// DELETE: app_args[1]=box_key(32 bytes)
txn ApplicationArgs 1
box_del
pop
b allow

allow:
int 1
return
"""

CLEAR_TEAL = """#pragma version 9
int 1
return
"""


def deploy_vault():
    from algosdk.v2client import algod
    from algosdk import account, mnemonic, transaction

    ALGOD_TOKEN  = os.getenv("ALGOD_TOKEN", "")
    ALGOD_SERVER = os.getenv("ALGOD_SERVER", "https://testnet-api.algonode.cloud")
    MNEMONIC     = os.getenv("ALGORAND_DEPLOYER_MNEMONIC", "")

    if not MNEMONIC:
        print("❌ ALGORAND_DEPLOYER_MNEMONIC not set in .env")
        print("   Add your 25-word Lute wallet mnemonic to .env and retry.")
        sys.exit(1)

    # ── Check if already deployed ──────────────────────
    existing = os.getenv("CREDENTIAL_VAULT_APP_ID", "")
    if existing:
        print(f"✅ Vault already deployed. App ID: {existing}")
        print("   To redeploy, remove CREDENTIAL_VAULT_APP_ID from .env")
        return int(existing)

    algod_client = algod.AlgodClient(ALGOD_TOKEN, ALGOD_SERVER)
    private_key  = mnemonic.to_private_key(MNEMONIC)
    address      = account.address_from_private_key(private_key)

    print(f"\n🚀 Deploying CredentialVault contract to Algorand TestNet...")
    print(f"   Deployer: {address}")

    # Check balance
    try:
        info    = algod_client.account_info(address)
        balance = info.get("amount", 0) / 1_000_000
        print(f"   Balance: {balance:.6f} ALGO")
        if balance < 0.5:
            print("   ⚠️  Low balance. Fund at: https://bank.testnet.algorand.network")
    except Exception as e:
        print(f"   ⚠️  Could not check balance: {e}")

    # ── Compile TEAL ──────────────────────────────────
    print("   Compiling TEAL...")
    approval_result = algod_client.compile(APPROVAL_TEAL)
    clear_result    = algod_client.compile(CLEAR_TEAL)

    approval_bytes = base64.b64decode(approval_result["result"])
    clear_bytes    = base64.b64decode(clear_result["result"])

    # ── Create application ────────────────────────────
    params = algod_client.suggested_params()

    txn = transaction.ApplicationCreateTxn(
        sender=address,
        sp=params,
        on_complete=transaction.OnComplete.NoOpOC,
        approval_program=approval_bytes,
        clear_program=clear_bytes,
        # No global/local state — all data lives in boxes
        global_schema=transaction.StateSchema(num_uints=0, num_byte_slices=0),
        local_schema=transaction.StateSchema(num_uints=0, num_byte_slices=0),
    )

    signed_txn = txn.sign(private_key)
    tx_id      = algod_client.send_transaction(signed_txn)

    print(f"   TX submitted: {tx_id}")
    print("   Waiting for confirmation (~3.3 seconds)...")

    result = transaction.wait_for_confirmation(algod_client, tx_id, 4)
    app_id = result["application-index"]

    print(f"\n✅ CredentialVault deployed successfully!")
    print(f"   App ID:   {app_id}")
    print(f"   Explorer: https://testnet.algoexplorer.io/application/{app_id}")

    # ── Write App ID to .env ──────────────────────────
    env_path = Path(".env")
    if env_path.exists():
        content = env_path.read_text()
        if "CREDENTIAL_VAULT_APP_ID" in content:
            lines = [
                f'CREDENTIAL_VAULT_APP_ID="{app_id}"'
                if line.startswith("CREDENTIAL_VAULT_APP_ID") else line
                for line in content.splitlines()
            ]
            env_path.write_text("\n".join(lines) + "\n")
        else:
            with open(env_path, "a") as f:
                f.write(f'\nCREDENTIAL_VAULT_APP_ID="{app_id}"\n')
        print(f"   ✅ CREDENTIAL_VAULT_APP_ID written to .env")
    else:
        print(f"\n   ⚠️  .env not found. Add this line manually:")
        print(f'   CREDENTIAL_VAULT_APP_ID="{app_id}"')

    print("\n🎉 Setup complete. OPSonic vault is ready.")
    return app_id


def verify_vault(app_id: int):
    """Quick sanity check — confirms the contract is live on testnet."""
    from algosdk.v2client import algod

    ALGOD_TOKEN  = os.getenv("ALGOD_TOKEN", "")
    ALGOD_SERVER = os.getenv("ALGOD_SERVER", "https://testnet-api.algonode.cloud")

    algod_client = algod.AlgodClient(ALGOD_TOKEN, ALGOD_SERVER)

    try:
        info = algod_client.application_info(app_id)
        print(f"\n🔍 Vault verification:")
        print(f"   App ID:   {app_id}")
        print(f"   Creator:  {info['params']['creator']}")
        print(f"   Deleted:  {info.get('deleted', False)}")
        print(f"   ✅ Vault contract is live and responsive.")
    except Exception as e:
        print(f"   ❌ Vault verification failed: {e}")


if __name__ == "__main__":
    app_id = deploy_vault()
    verify_vault(app_id)
