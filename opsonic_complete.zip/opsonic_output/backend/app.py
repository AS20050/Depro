import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent))

from dotenv import load_dotenv
load_dotenv()

import os
import traceback
import shutil
import time

from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from fileUploadLayer.services.zip_handler import extract_zip
from fileUploadLayer.services.github_handler import clone_github_repo
from codeReviewLayer.reviewer import review_project
from aiLayer.decision_engine import decide_and_execute
from auth.aws_credentials import resolve_aws_credentials, inject_aws_creds

app = FastAPI(title="Opsonic")

# ==========================================
# CORS
# ==========================================
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Storage dirs ──────────────────────────
UPLOAD_DIR  = Path("storage/uploads")
EXTRACT_DIR = Path("storage/extracted/zip")

UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
EXTRACT_DIR.mkdir(parents=True, exist_ok=True)


# =========================================================
# 1️⃣  GENERIC UPLOAD + ORCHESTRATION
# =========================================================
@app.post("/upload")
async def upload_file(
    file: UploadFile = File(...),
    aws_access_key_id:     str | None = Form(None),
    aws_secret_access_key: str | None = Form(None)
):
    try:
        # ── Sanitise filename ──────────────────────────
        original_name = file.filename or "unknown_file"
        clean_name    = os.path.basename(original_name).strip() or f"upload_{int(time.time())}.bin"
        filename      = clean_name
        upload_path   = UPLOAD_DIR / filename

        print(f"📝 Saving to: {upload_path}")
        with open(upload_path, "wb") as f:
            shutil.copyfileobj(file.file, f)
        print(f"\n📥 File uploaded: {upload_path}")

        # ── ZIP → review → AI decision ─────────────────
        if filename.endswith(".zip"):
            extract_path = EXTRACT_DIR
            if extract_path.exists():
                shutil.rmtree(extract_path)
            extract_path.mkdir(parents=True, exist_ok=True)

            extract_zip(upload_path, extract_path)
            print(f"📂 ZIP extracted to: {extract_path}")

            review_output      = review_project(str(extract_path))
            deployment_context = review_output.copy()
            deployment_context["project_path"] = str(extract_path)
            deployment_context["filename"]     = filename
            deployment_context["repo_url"]     = None
            deployment_context["github_token"] = None

            return decide_and_execute(deployment_context)

        # ── JAR → vault resolve → EC2 ──────────────────
        if filename.endswith(".jar"):
            print("\n📦 JAR detected → EC2 deployment")

            # Resolve credentials (vault-aware)
            creds = resolve_aws_credentials(
                access_key_id=aws_access_key_id,
                secret_access_key=aws_secret_access_key,
                region="ap-south-1"
            )

            # Auto-save to Algorand vault when fresh creds provided by frontend
            if aws_access_key_id and aws_secret_access_key:
                try:
                    from mcpServer.infraScripts.algorand_credential_store import store_aws_credentials
                    vault_result = store_aws_credentials(creds)
                    print(f"🔐 [VAULT] Auto-saved to Algorand. "
                          f"Box: {vault_result.get('box_key', '')[:16]}...")
                except Exception as e:
                    # Non-fatal — vault failure must not block deployment
                    print(f"⚠️  [VAULT] Auto-save failed (non-fatal): {e}")

            inject_aws_creds(creds)

            os.environ["APP_FILE"] = filename
            os.environ["APP_PORT"] = "8080"
            os.environ["KEY_NAME"] = "ubuntu-auto-keypair-v2"

            root_jar_path = Path(filename)
            if root_jar_path.exists():
                try:
                    os.remove(root_jar_path)
                except Exception:
                    pass

            shutil.copy(upload_path, root_jar_path)
            print(f"📄 Copied JAR to project root: {root_jar_path}")

            result = decide_and_execute({
                "artifact_type": "jar",
                "artifact_path": str(upload_path)
            })
            result["vault_stored"] = True
            return result

        # ── Unsupported ────────────────────────────────
        return {
            "status":  "uploaded",
            "file":    filename,
            "message": "File stored. No deployment pipeline for this file type yet."
        }

    except Exception as e:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))


# =========================================================
# 2️⃣  STANDALONE REVIEW
# =========================================================
class ReviewRequest(BaseModel):
    project_path: str

@app.post("/review")
async def review_repo(request: ReviewRequest):
    try:
        print(f"\n🔍 Starting review for: {request.project_path}")
        result = review_project(request.project_path)
        return {"status": "success", "review": result}
    except Exception as e:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))


# =========================================================
# 3️⃣  GITHUB UPLOAD
# =========================================================
@app.post("/upload/github")
async def upload_github_repo(
    repo_url:     str           = Form(...),
    github_token: str | None    = Form(None)
):
    try:
        repo_path = clone_github_repo(repo_url, github_token)
        print(f"\n📦 GitHub repo cloned to: {repo_path}")

        review_output      = review_project(repo_path)
        deployment_context = review_output.copy()
        deployment_context["project_path"] = repo_path
        deployment_context["filename"]     = repo_url.split("/")[-1]
        deployment_context["repo_url"]     = repo_url
        deployment_context["github_token"] = github_token

        return decide_and_execute(deployment_context)

    except Exception as e:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))


# =========================================================
# 4️⃣  VAULT — CHECK
# =========================================================
class VaultCheckRequest(BaseModel):
    access_key_id: str

@app.post("/vault/check")
async def vault_check(request: VaultCheckRequest):
    """Check if credentials exist in Algorand vault (no cost, read-only)."""
    try:
        from mcpServer.infraScripts.algorand_credential_store import has_credentials
        exists = has_credentials(request.access_key_id)
        return {
            "status":  "success",
            "exists":  exists,
            "message": "Credentials found in Algorand vault." if exists
                       else "No credentials stored for this access key ID."
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# =========================================================
# 5️⃣  VAULT — STORE
# =========================================================
class VaultStoreRequest(BaseModel):
    aws_access_key_id:     str
    aws_secret_access_key: str
    aws_default_region:    str = "ap-south-1"

@app.post("/vault/store")
async def vault_store(request: VaultStoreRequest):
    """Explicitly encrypt and store credentials in Algorand vault."""
    try:
        from mcpServer.infraScripts.algorand_credential_store import store_aws_credentials
        result = store_aws_credentials({
            "AWS_ACCESS_KEY_ID":     request.aws_access_key_id,
            "AWS_SECRET_ACCESS_KEY": request.aws_secret_access_key,
            "AWS_DEFAULT_REGION":    request.aws_default_region
        })
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# =========================================================
# 6️⃣  VAULT — DELETE
# =========================================================
class VaultDeleteRequest(BaseModel):
    access_key_id: str

@app.post("/vault/delete")
async def vault_delete(request: VaultDeleteRequest):
    """Delete credentials from Algorand vault and reclaim MBR."""
    try:
        from mcpServer.infraScripts.algorand_credential_store import delete_aws_credentials
        return delete_aws_credentials(request.access_key_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
