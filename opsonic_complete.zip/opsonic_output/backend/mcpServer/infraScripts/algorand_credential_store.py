# mcpServer/infraScripts/algorand_credential_store.py

import os
import json
import base64
import hashlib
from dotenv import load_dotenv

from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives import hashes

from algosdk.v2client import algod
from algosdk import account, mnemonic, transaction

load_dotenv()

# ─────────────────────────────────────────────────────
# CONSTANTS
# ─────────────────────────────────────────────────────
HKDF_INFO  = b"opsonic-aws-creds-v1"
KEY_SIZE   = 32   # AES-256
NONCE_SIZE = 12   # GCM standard nonce


# ─────────────────────────────────────────────────────
# INTERNAL HELPERS
# ─────────────────────────────────────────────────────

def _get_algod_client() -> algod.AlgodClient:
    token  = os.getenv("ALGOD_TOKEN", "")
    server = os.getenv("ALGOD_SERVER", "https://testnet-api.algonode.cloud")
    return algod.AlgodClient(token, server)


def _get_deployer():
    """Returns (pk_bytes, private_key_str, address)"""
    raw = os.getenv("ALGORAND_DEPLOYER_MNEMONIC", "")
    if not raw:
        raise EnvironmentError("ALGORAND_DEPLOYER_MNEMONIC not set in .env")
    private_key = mnemonic.to_private_key(raw)
    addr        = account.address_from_private_key(private_key)
    pk_bytes    = base64.b64decode(private_key)[:32]
    return pk_bytes, private_key, addr


def _get_vault_app_id() -> int:
    app_id = os.getenv("CREDENTIAL_VAULT_APP_ID", "")
    if not app_id:
        raise EnvironmentError(
            "CREDENTIAL_VAULT_APP_ID not set. Run: python scripts/setup_vault.py"
        )
    return int(app_id)


def _derive_box_key(access_key_id: str) -> bytes:
    """32-byte deterministic box name from access key ID."""
    return hashlib.sha256(access_key_id.encode()).digest()


def _derive_encryption_key(private_key_bytes: bytes, access_key_id: str) -> bytes:
    """
    AES-256 key via HKDF-SHA256.
    ikm  = Algorand private key seed bytes (never leaves server)
    salt = AWS_ACCESS_KEY_ID (per-user salt)
    info = static context string
    Neither input alone can reconstruct the key.
    """
    hkdf = HKDF(
        algorithm=hashes.SHA256(),
        length=KEY_SIZE,
        salt=access_key_id.encode(),
        info=HKDF_INFO
    )
    return hkdf.derive(private_key_bytes)


def _encrypt(data: dict, encryption_key: bytes) -> str:
    """AES-256-GCM encrypt. Returns base64(nonce + ciphertext + tag)."""
    aesgcm    = AESGCM(encryption_key)
    nonce     = os.urandom(NONCE_SIZE)
    # separators removes whitespace — smaller blob = lower MBR cost
    plaintext = json.dumps(data, separators=(',', ':')).encode()
    ciphertext_with_tag = aesgcm.encrypt(nonce, plaintext, None)
    packed = nonce + ciphertext_with_tag
    return base64.b64encode(packed).decode()


def _decrypt(encrypted_blob: str, encryption_key: bytes) -> dict:
    """AES-256-GCM decrypt. Raises ValueError on tamper detection (GCM auth tag)."""
    try:
        packed              = base64.b64decode(encrypted_blob)
        nonce               = packed[:NONCE_SIZE]
        ciphertext_with_tag = packed[NONCE_SIZE:]
        aesgcm              = AESGCM(encryption_key)
        plaintext           = aesgcm.decrypt(nonce, ciphertext_with_tag, None)
        return json.loads(plaintext.decode())
    except Exception as e:
        raise ValueError(
            f"Credential decryption failed — possible tampering or wrong key: {e}"
        )


# ─────────────────────────────────────────────────────
# PUBLIC API
# ─────────────────────────────────────────────────────

def store_aws_credentials(creds: dict) -> dict:
    """
    Encrypt and store AWS credentials in Algorand box storage.

    Args:
        creds: {
            "AWS_ACCESS_KEY_ID": "AKIA...",
            "AWS_SECRET_ACCESS_KEY": "...",
            "AWS_DEFAULT_REGION": "ap-south-1"
        }
    """
    access_key_id = creds.get("AWS_ACCESS_KEY_ID", "")
    if not access_key_id:
        raise ValueError("AWS_ACCESS_KEY_ID is required")

    algod_client            = _get_algod_client()
    pk_bytes, pk_str, addr  = _get_deployer()
    vault_app_id            = _get_vault_app_id()

    print(f"\n🔐 [VAULT] Storing credentials for: {access_key_id[:8]}****")

    # Derive keys
    box_key        = _derive_box_key(access_key_id)
    encryption_key = _derive_encryption_key(pk_bytes, access_key_id)

    # Encrypt
    encrypted_blob = _encrypt(creds, encryption_key)
    blob_bytes     = encrypted_blob.encode()

    print(f"   Encrypted blob: {len(blob_bytes)} bytes")

    # MBR for new box: 2500 + 400 * (key_size + value_size) microALGO
    mbr = 2500 + 400 * (len(box_key) + len(blob_bytes))
    print(f"   Box MBR: {mbr / 1_000_000:.6f} ALGO")

    params = algod_client.suggested_params()

    # App call to store the box
    app_call_txn = transaction.ApplicationCallTxn(
        sender=addr,
        sp=params,
        index=vault_app_id,
        on_complete=transaction.OnComplete.NoOpOC,
        app_args=[b"store", box_key, blob_bytes],
        boxes=[(vault_app_id, box_key)],
    )

    # MBR payment to the contract account
    import algosdk.encoding as enc
    contract_addr = enc.encode_address(
        enc.checksum(b"appID" + vault_app_id.to_bytes(8, "big"))
    )
    pay_txn = transaction.PaymentTransaction(
        sender=addr,
        sp=params,
        receiver=contract_addr,
        amt=mbr
    )

    # Group both transactions atomically
    gid            = transaction.calculate_group_id([pay_txn, app_call_txn])
    pay_txn.group  = gid
    app_call_txn.group = gid

    signed_pay = pay_txn.sign(pk_str)
    signed_app = app_call_txn.sign(pk_str)

    tx_id = algod_client.send_transactions([signed_pay, signed_app])
    print(f"   TX submitted: {tx_id}")
    transaction.wait_for_confirmation(algod_client, tx_id, 4)

    box_key_hex  = box_key.hex()
    explorer_url = f"https://testnet.algoexplorer.io/application/{vault_app_id}"

    print(f"✅ [VAULT] Credentials stored on Algorand.")
    print(f"   Box key (hex): {box_key_hex[:16]}...")

    return {
        "status":       "success",
        "box_key":      box_key_hex,
        "vault_app_id": vault_app_id,
        "explorer_url": explorer_url,
        "message":      "AWS credentials encrypted and stored on Algorand."
    }


def retrieve_aws_credentials(access_key_id: str) -> dict:
    """
    Retrieve and decrypt AWS credentials from Algorand box storage.
    Read-only — no transaction, no ALGO cost.
    """
    algod_client           = _get_algod_client()
    pk_bytes, pk_str, addr = _get_deployer()
    vault_app_id           = _get_vault_app_id()

    print(f"\n🔓 [VAULT] Retrieving credentials for: {access_key_id[:8]}****")

    box_key = _derive_box_key(access_key_id)

    try:
        box_response = algod_client.application_box_by_name(vault_app_id, box_key)
    except Exception as e:
        raise KeyError(
            f"No credentials found for access key ID: {access_key_id[:8]}****"
        ) from e

    # Box value comes back base64-encoded from algod
    encrypted_blob = base64.b64decode(box_response["value"]).decode()

    encryption_key = _derive_encryption_key(pk_bytes, access_key_id)
    creds          = _decrypt(encrypted_blob, encryption_key)

    print(f"✅ [VAULT] Credentials retrieved and decrypted.")
    return creds


def delete_aws_credentials(access_key_id: str) -> dict:
    """
    Delete credentials box and reclaim MBR deposit.
    """
    algod_client           = _get_algod_client()
    pk_bytes, pk_str, addr = _get_deployer()
    vault_app_id           = _get_vault_app_id()

    print(f"\n🗑️  [VAULT] Deleting credentials for: {access_key_id[:8]}****")

    box_key = _derive_box_key(access_key_id)
    params  = algod_client.suggested_params()

    txn = transaction.ApplicationCallTxn(
        sender=addr,
        sp=params,
        index=vault_app_id,
        on_complete=transaction.OnComplete.NoOpOC,
        app_args=[b"delete", box_key],
        boxes=[(vault_app_id, box_key)],
    )

    signed = txn.sign(pk_str)
    tx_id  = algod_client.send_transaction(signed)
    transaction.wait_for_confirmation(algod_client, tx_id, 4)

    print(f"✅ [VAULT] Credentials deleted. MBR reclaimed.")
    return {"status": "success", "message": "Credentials deleted from Algorand vault."}


def has_credentials(access_key_id: str) -> bool:
    """Check if credentials exist. No transaction, no cost."""
    algod_client = _get_algod_client()
    vault_app_id = _get_vault_app_id()
    box_key      = _derive_box_key(access_key_id)
    try:
        algod_client.application_box_by_name(vault_app_id, box_key)
        return True
    except Exception:
        return False
