# mcpServer/infraScripts/algorand_deploy.py

import os
import base64
import subprocess
from pathlib import Path
from dotenv import load_dotenv

from algosdk.v2client import algod
from algosdk import account, mnemonic, transaction
import algosdk.encoding as enc

load_dotenv()


def _get_algod_client():
    token  = os.getenv("ALGOD_TOKEN", "")
    server = os.getenv("ALGOD_SERVER", "https://testnet-api.algonode.cloud")
    return algod.AlgodClient(token, server)


def _get_deployer():
    raw = os.getenv("ALGORAND_DEPLOYER_MNEMONIC", "")
    if not raw:
        raise EnvironmentError("ALGORAND_DEPLOYER_MNEMONIC not set in .env")
    private_key = mnemonic.to_private_key(raw)
    address     = account.address_from_private_key(private_key)
    return private_key, address


def _find_project_root(start_path: str) -> Path:
    """Handles nested zip extraction by finding algokit.toml."""
    base = Path(start_path)
    if (base / "algokit.toml").exists():
        return base
    for sub in base.iterdir():
        if sub.is_dir() and (sub / "algokit.toml").exists():
            print(f"🔍 [ALGO] Found project root at: {sub}")
            return sub
    return base


def _find_abi_spec(project_root: Path) -> Path | None:
    """Find application.json or arc32.json (AlgoKit ABI spec)."""
    for pattern in ["**/application.json", "**/arc32.json"]:
        for match in project_root.rglob(pattern):
            if "node_modules" in match.parts or ".venv" in match.parts:
                continue
            print(f"📄 [ALGO] Found ABI spec: {match}")
            return match
    return None


def _build_with_algokit(project_root: Path) -> bool:
    """Run algokit compile. Non-fatal if algokit not installed."""
    try:
        print("🔨 [ALGO] Running algokit compile...")
        result = subprocess.run(
            ["algokit", "compile", "python", "."],
            cwd=str(project_root),
            capture_output=True,
            text=True,
            timeout=120
        )
        if result.returncode == 0:
            print("✅ [ALGO] Compile successful.")
            return True
        else:
            print(f"⚠️  [ALGO] Compile warning: {result.stderr[:300]}")
            return False
    except FileNotFoundError:
        print("⚠️  [ALGO] algokit not found. Skipping compile step.")
        return False
    except subprocess.TimeoutExpired:
        print("⚠️  [ALGO] Compile timed out.")
        return False


def _deploy_via_abi_spec(algod_client, private_key, address, abi_spec_path: Path) -> dict:
    """Deploy ARC-4 contract using algokit-utils ApplicationClient."""
    try:
        from algokit_utils import ApplicationClient, ApplicationSpecification, Account

        print("📦 [ALGO] Loading ABI spec...")
        spec             = ApplicationSpecification.from_json(abi_spec_path.read_text())
        deployer_account = Account(private_key=private_key, address=address)

        client = ApplicationClient(
            algod_client=algod_client,
            app_spec=spec,
            signer=deployer_account,
            sender=address
        )

        print("🚀 [ALGO] Deploying via ApplicationClient...")
        client.create()

        app_id      = client.app_id
        app_address = client.app_address

        print(f"✅ [ALGO] Contract deployed! App ID: {app_id}")
        return {"status": "success", "app_id": app_id, "app_address": app_address, "method": "abi_spec"}

    except Exception as e:
        print(f"❌ [ALGO] ABI spec deploy failed: {e}")
        raise


def _deploy_raw_teal(algod_client, private_key, address, project_root: Path) -> dict:
    """Fallback: deploy using raw approval + clear TEAL files."""
    print("🔄 [ALGO] Falling back to raw TEAL deployment...")

    approval_teal = None
    clear_teal    = None

    for f in project_root.rglob("*.teal"):
        name = f.name.lower()
        if "approval" in name:
            approval_teal = f
        elif "clear" in name:
            clear_teal = f

    if not approval_teal or not clear_teal:
        raise FileNotFoundError(
            "❌ Could not find approval.teal and clear.teal. Run algokit compile first."
        )

    approval_result = algod_client.compile(approval_teal.read_text())
    clear_result    = algod_client.compile(clear_teal.read_text())

    approval_bytes = base64.b64decode(approval_result["result"])
    clear_bytes    = base64.b64decode(clear_result["result"])

    params = algod_client.suggested_params()

    txn = transaction.ApplicationCreateTxn(
        sender=address,
        sp=params,
        on_complete=transaction.OnComplete.NoOpOC,
        approval_program=approval_bytes,
        clear_program=clear_bytes,
        global_schema=transaction.StateSchema(num_uints=1, num_byte_slices=1),
        local_schema=transaction.StateSchema(num_uints=0, num_byte_slices=0),
    )

    signed_txn = txn.sign(private_key)
    tx_id      = algod_client.send_transaction(signed_txn)
    print(f"   TX submitted: {tx_id}")

    result  = transaction.wait_for_confirmation(algod_client, tx_id, 4)
    app_id  = result["application-index"]
    app_address = enc.encode_address(
        enc.checksum(b"appID" + app_id.to_bytes(8, "big"))
    )

    print(f"✅ [ALGO] Raw TEAL deploy successful. App ID: {app_id}")
    return {"status": "success", "app_id": app_id, "app_address": app_address, "method": "raw_teal"}


def deploy_algorand_contract_ex(project_path: str, contract_file: str | None = None) -> dict:
    """
    Main entry: deploy Algorand smart contract to testnet.
    1. Find project root
    2. Try algokit compile
    3. Deploy via ABI spec (preferred) or raw TEAL (fallback)
    """
    algod_client        = _get_algod_client()
    private_key, address = _get_deployer()

    print(f"\n🚀 [ALGO] Starting deployment from: {project_path}")
    print(f"   Deployer: {address}")

    project_root = _find_project_root(project_path)
    print(f"   Project root: {project_root}")

    _build_with_algokit(project_root)

    abi_spec = _find_abi_spec(project_root)
    if abi_spec:
        result = _deploy_via_abi_spec(algod_client, private_key, address, abi_spec)
    else:
        print("⚠️  [ALGO] No ABI spec. Attempting raw TEAL.")
        result = _deploy_raw_teal(algod_client, private_key, address, project_root)

    app_id               = result["app_id"]
    result["explorer_url"] = f"https://testnet.algoexplorer.io/application/{app_id}"
    result["network"]      = "algorand-testnet"

    print(f"🌐 [ALGO] Explorer: {result['explorer_url']}")
    return result
