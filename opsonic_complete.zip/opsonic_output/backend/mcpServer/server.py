# mcpServer/server.py

from mcpServer.tools.ec2_provision        import provision_ec2_instance
from mcpServer.tools.java_deploy          import deploy_java_app_ec2
from mcpServer.tools.source_deploy        import deploy_source_ec2
from mcpServer.tools.amplify_deploy       import deploy_amplify_node_ex
from mcpServer.tools.amplify_cicd_tools   import connect_amplify_cicd
from mcpServer.tools.algorand_deploy      import deploy_algorand_contract
from mcpServer.tools.algorand_credentials import (
    vault_store_credentials,
    vault_retrieve_credentials,
    vault_delete_credentials,
    vault_check_credentials
)

TOOLS = {
    # ── Existing ─────────────────────────────────────────
    "provision_ec2_instance":     provision_ec2_instance,
    "deploy_java_app_ec2":        deploy_java_app_ec2,
    "deploy_source_ec2":          deploy_source_ec2,
    "deploy_to_amplify":          deploy_amplify_node_ex,
    "connect_amplify_cicd":       connect_amplify_cicd,

    # ── Algorand dApp deployment ──────────────────────────
    "deploy_algorand_contract":   deploy_algorand_contract,

    # ── Credential vault ─────────────────────────────────
    "vault_store_credentials":    vault_store_credentials,
    "vault_retrieve_credentials": vault_retrieve_credentials,
    "vault_delete_credentials":   vault_delete_credentials,
    "vault_check_credentials":    vault_check_credentials,
}


def call_tool(tool_name: str, args: dict):
    if tool_name not in TOOLS:
        raise ValueError(f"Unknown MCP tool: '{tool_name}'")
    return TOOLS[tool_name](**args)
