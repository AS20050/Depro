# mcpServer/tools/algorand_credentials.py

import traceback
from mcpServer.infraScripts.algorand_credential_store import (
    store_aws_credentials,
    retrieve_aws_credentials,
    delete_aws_credentials,
    has_credentials
)


def vault_store_credentials(creds: dict) -> dict:
    """MCP Tool: Encrypt and store AWS credentials in Algorand vault."""
    print("🔧 [TOOL] vault_store_credentials")
    try:
        return store_aws_credentials(creds)
    except Exception as e:
        traceback.print_exc()
        return {"status": "error", "message": str(e)}


def vault_retrieve_credentials(access_key_id: str) -> dict:
    """MCP Tool: Retrieve and decrypt AWS credentials from Algorand vault."""
    print(f"🔧 [TOOL] vault_retrieve_credentials: {access_key_id[:8]}****")
    try:
        creds = retrieve_aws_credentials(access_key_id)
        return {"status": "success", "credentials": creds}
    except KeyError as e:
        return {"status": "not_found", "message": str(e)}
    except ValueError as e:
        return {"status": "error", "message": str(e)}
    except Exception as e:
        traceback.print_exc()
        return {"status": "error", "message": str(e)}


def vault_delete_credentials(access_key_id: str) -> dict:
    """MCP Tool: Delete credentials from Algorand vault."""
    print(f"🔧 [TOOL] vault_delete_credentials: {access_key_id[:8]}****")
    try:
        return delete_aws_credentials(access_key_id)
    except Exception as e:
        traceback.print_exc()
        return {"status": "error", "message": str(e)}


def vault_check_credentials(access_key_id: str) -> dict:
    """MCP Tool: Check if credentials exist without retrieving them."""
    print(f"🔧 [TOOL] vault_check_credentials: {access_key_id[:8]}****")
    exists = has_credentials(access_key_id)
    return {
        "status":  "success",
        "exists":  exists,
        "message": "Credentials found in vault." if exists else "No credentials stored."
    }
