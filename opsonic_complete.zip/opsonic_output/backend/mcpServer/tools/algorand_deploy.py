# mcpServer/tools/algorand_deploy.py

import traceback
from mcpServer.infraScripts.algorand_deploy import deploy_algorand_contract_ex


def deploy_algorand_contract(project_path: str, contract_file: str | None = None) -> dict:
    """
    MCP Tool: Deploys an Algorand smart contract to testnet.
    Supports ARC-4 (AlgoKit) and raw TEAL projects.
    """
    print(f"🔧 [TOOL] deploy_algorand_contract | path: {project_path}")
    try:
        return deploy_algorand_contract_ex(
            project_path=project_path,
            contract_file=contract_file
        )
    except Exception as e:
        print("❌ [TOOL] Algorand deployment error:")
        traceback.print_exc()
        return {"status": "error", "message": str(e), "app_id": None, "app_address": None}
